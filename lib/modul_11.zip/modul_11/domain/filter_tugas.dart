
import 'tugas_performa.dart';

/// Kriteria penyaringan daftar tugas.
class KriteriaFilter {
  const KriteriaFilter({
    this.kueri = '',
    this.status,
    this.mataKuliah,
  });

  final String kueri;
  final StatusTugas? status;
  final String? mataKuliah;

  /// Membuat kriteria filter baru berdasarkan kriteria sebelumnya.
  KriteriaFilter salinDengan({
    String? kueri,
    StatusTugas? status,
    String? mataKuliah,
    bool hapusStatus = false,
    bool hapusMataKuliah = false,
  }) =>
      KriteriaFilter(
        kueri: kueri ?? this.kueri,
        status: hapusStatus ? null : (status ?? this.status),
        mataKuliah: hapusMataKuliah
            ? null
            : (mataKuliah ?? this.mataKuliah),
      );
}

/// Menyaring tugas berdasarkan pencarian, status, dan mata kuliah.
List<TugasPerforma> saringTugas(
  List<TugasPerforma> sumber,
  KriteriaFilter kriteria,
) {
  final String kueri = kriteria.kueri.trim().toLowerCase();

  return sumber.where((TugasPerforma tugas) {
    // Memeriksa kesesuaian status tugas.
    final bool cocokStatus =
        kriteria.status == null ||
        tugas.status == kriteria.status;

    // Memeriksa kesesuaian teks pencarian.
    final bool cocokTeks =
        kueri.isEmpty ||
        tugas.kunciPencarian.contains(kueri);

    // Memeriksa kesesuaian mata kuliah.
    final bool cocokMataKuliah =
        kriteria.mataKuliah == null ||
        tugas.mataKuliah == kriteria.mataKuliah;

    // Ketiga kriteria harus terpenuhi.
    return cocokStatus &&
        cocokTeks &&
        cocokMataKuliah;
  }).toList(growable: false);
}
