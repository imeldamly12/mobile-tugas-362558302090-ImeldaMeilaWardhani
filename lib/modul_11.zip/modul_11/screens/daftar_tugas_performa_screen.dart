
import 'package:flutter/material.dart';

import '../data/sumber_tugas_contoh.dart';
import '../domain/filter_tugas.dart';
import '../domain/tugas_performa.dart';
import '../widgets/kartu_tugas_performa.dart';

class LayarDaftarTugasPerforma extends StatefulWidget {
  const LayarDaftarTugasPerforma({
    this.sumber,
    super.key,
  });

  final List<TugasPerforma>? sumber;

  @override
  State<LayarDaftarTugasPerforma> createState() =>
      _LayarDaftarTugasPerformaState();
}

class _LayarDaftarTugasPerformaState
    extends State<LayarDaftarTugasPerforma> {
  final TextEditingController _pencarian =
      TextEditingController();

  late final List<TugasPerforma> _semuaTugas =
      widget.sumber ?? buatTugasContoh();

  KriteriaFilter _kriteria = const KriteriaFilter();

  late List<TugasPerforma> _hasil = _semuaTugas;

  /// Menerapkan seluruh kriteria filter pada daftar tugas.
  void _terapkan(KriteriaFilter kriteria) {
    setState(() {
      _kriteria = kriteria;
      _hasil = saringTugas(_semuaTugas, kriteria);
    });
  }

  @override
  void dispose() {
    _pencarian.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tugas Kuliah'),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          // Kolom pencarian tugas.
          Padding(
            padding: const EdgeInsets.fromLTRB(
              16, 12, 16, 4,
            ),
            child: TextField(
              key: const ValueKey<String>('task-search'),
              controller: _pencarian,
              onChanged: (String nilai) {
                _terapkan(
                  _kriteria.salinDengan(kueri: nilai),
                );
              },
              decoration: const InputDecoration(
                labelText: 'Cari tugas atau mata kuliah',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
              ),
            ),
          ),

          // Filter berdasarkan status tugas.
          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 12,
            ),
            child: Wrap(
              spacing: 8,
              children: <Widget>[
                _chipStatus('Semua', null),
                _chipStatus('Aktif', StatusTugas.aktif),
                _chipStatus('Selesai', StatusTugas.selesai),
              ],
            ),
          ),

          // Judul filter mata kuliah.
          const Padding(
            padding: EdgeInsets.fromLTRB(
              16, 8, 16, 4,
            ),
            child: Text(
              'Filter Mata Kuliah',
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
          ),

          // Pilihan filter mata kuliah.
          _filterMataKuliah(),

          // Informasi jumlah tugas yang ditampilkan.
          Padding(
            padding: const EdgeInsets.fromLTRB(
              16, 4, 16, 8,
            ),
            child: Text(
              'Menampilkan ${_hasil.length} '
              'dari ${_semuaTugas.length} tugas',
              key: const ValueKey<String>('result-count'),
            ),
          ),

          // Daftar tugas.
          Expanded(
            child: _hasil.isEmpty
                ? const Center(
                    child: Text(
                      'Tidak ada tugas yang cocok.',
                    ),
                  )
                : ListView.builder(
                    key: const ValueKey<String>('task-list'),
                    itemCount: _hasil.length,
                    itemBuilder: (
                      BuildContext context,
                      int index,
                    ) {
                      return KartuTugasPerforma(
                        tugas: _hasil[index],
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  /// Membuat pilihan filter status tugas.
  Widget _chipStatus(
    String label,
    StatusTugas? status,
  ) {
    return FilterChip(
      label: Text(label),
      selected: _kriteria.status == status,
      onSelected: (_) {
        _terapkan(
          status == null
              ? _kriteria.salinDengan(
                  hapusStatus: true,
                )
              : _kriteria.salinDengan(
                  status: status,
                ),
        );
      },
    );
  }

  /// Membuat pilihan filter untuk satu mata kuliah.
  Widget _chipMataKuliah(String mataKuliah) {
    return ChoiceChip(
      label: Text(mataKuliah),
      selected: _kriteria.mataKuliah == mataKuliah,
      onSelected: (_) {
        _terapkan(
          _kriteria.salinDengan(
            mataKuliah: mataKuliah,
          ),
        );
      },
    );
  }

  /// Menampilkan seluruh pilihan mata kuliah.
  Widget _filterMataKuliah() {
    final Set<String> daftarMataKuliah =
        _semuaTugas
            .map((TugasPerforma tugas) => tugas.mataKuliah)
            .toSet();

    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: 12,
      ),
      child: Wrap(
        spacing: 8,
        runSpacing: 4,
        children: <Widget>[
          ChoiceChip(
            label: const Text('Semua Mata Kuliah'),
            selected: _kriteria.mataKuliah == null,
            onSelected: (_) {
              _terapkan(
                _kriteria.salinDengan(
                  hapusMataKuliah: true,
                ),
              );
            },
          ),
          ...daftarMataKuliah.map(
            (String mataKuliah) =>
                _chipMataKuliah(mataKuliah),
          ),
        ],
      ),
    );
  }
}
